<?php

// Prevent direct access
if (!defined('APP_INITIALIZED')) {
    http_response_code(403);
    exit('Access denied.');
}

// Secure secrets and API tokens
return [
    'ADMIN_API_TOKEN'     => 'f07fcbfe01d69839eaca976451fc1966d9e40cca416b4725f8647a163df06eb6',
    'OPENAI_API_KEY'      => 'sk-xxxxxxx',
    'GOOGLE_CREDENTIALS'  => __DIR__ . '/google-credentials.json',
    'GOOGLE_CLIENT_ID' => '121499076510-kad83vto4sv6krl886duiq1i9nhpmdsg.apps.googleusercontent.com', 
    'GOOGLE_CLIENT_SECRET' => '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',
    'GOOGLE_REDIRECT_URI' => 'https://yourdomain.com/api/auth/google/callback',
    'FACEBOOK_APP_ID' => '1795618628031942',
    'FACEBOOK_APP_SECRET' => '9628e2ef1dc3fe0619d5c9ba457b03d0',
    'APPLE_KEY_URL' => 'https://appleid.apple.com/auth/keys',
    'APPLE_TEAM_ID' => 'your-apple-team-id',
];
