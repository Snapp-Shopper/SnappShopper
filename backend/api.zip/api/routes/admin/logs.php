<?php
// Description: Admin endpoint for viewing, downloading, or clearing dev logs
require_once '../../initialize.php';

header('Content-Type: application/json');

// === AUTH CHECK ===
$headers = getallheaders();
$providedToken = $headers['Authorization'] ?? ($_GET['token'] ?? '');
if ($providedToken !== ADMIN_API_TOKEN) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

// === LOG CONFIG ===
$logFile = __DIR__ . '/../../logs/dev.log';
if (!file_exists($logFile)) {
    // Create the log file if it doesn't exist
    file_put_contents($logFile, '');
}

// === ROUTING ===
$action = $_GET['action'] ?? 'view';

switch ($action) {
    case 'view':
        if (!file_exists($logFile)) {
            echo json_encode(['status' => 'success', 'message' => 'No logs found.', 'log' => '']);
            exit;
        }

        $lines = file($logFile);
        $lastLines = array_slice($lines, -200); // limit to last 200 lines
        echo json_encode([
            'status' => 'success',
            'lines' => array_map('trim', $lastLines)
        ]);
        break;

    case 'download':
        if (!file_exists($logFile)) {
            echo json_encode(['status' => 'error', 'message' => 'Log file not found.']);
            exit;
        }

        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="dev.log"');
        readfile($logFile);
        exit;

    case 'clear':
        if (file_exists($logFile)) {
            unlink($logFile);
        }

        echo json_encode(['status' => 'success', 'message' => 'Log file cleared.']);
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
        break;
}
